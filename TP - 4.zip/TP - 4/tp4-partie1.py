import pandas
import matplotlib.pyplot as plt

# ----------------------------------------------------------------------------
# Importation du fichier excel
fichier = pandas.read_excel('./Tp4partie1.xlsx')
Fichier_complet = pandas.DataFrame(fichier)

# ----------------------------------------------------------------------------
# Camembert promo 2018
label = Fichier_complet['nom complet']
size = Fichier_complet['promo 2018']

plt.pie(size, labels=label, 
        autopct='%1.1f%%', shadow=True, startangle=90)

plt.axis('equal')
plt.show()

# ----------------------------------------------------------------------------
# Camembert promo 2019
label = Fichier_complet['nom complet']
size = Fichier_complet['promo 2019']

plt.pie(size, labels=label, 
        autopct='%1.1f%%', shadow=True, startangle=90)

plt.axis('equal')
plt.show()

# ----------------------------------------------------------------------------
# Affichage barplot
barWidth = 0.4
y1 = Fichier_complet['promo 2018']
y2 = Fichier_complet['promo 2019']
r1 = range(len(y1))
r2 = [x + barWidth for x in r1]

plt.bar(r1, y1, width = barWidth, color = ['deepskyblue' for i in y1],
           edgecolor = ['blue' for i in y1], linewidth = 1)

plt.bar(r2, y2, width = barWidth, color = ['yellowgreen' for i in y1],
           edgecolor = ['green' for i in y1], linewidth = 1)

plt.xticks(range(len(Fichier_complet['promo 2018'])), Fichier_complet['abregé']) 

plt.show()

