import pandas
import matplotlib.pyplot as plt
import numpy as np
# Question n°3: Sur le fichier tp4_partie2.xlsx, récupérer d’un seul coup les 2 feuilles.
fichier_excel = pandas.ExcelFile('./Tp4partie2.xlsx')
# Feuille 1
fichier_excel_f1 = pandas.read_excel(fichier_excel, 'taille_ent')
# Feuille 2
fichier_excel_f2 = pandas.read_excel(fichier_excel, 'nuage')

# Question n°4: Afficher un histogramme avec les classes proposées pour les bac +5, on utilisera bar
# Affichage barplot
barWidth = 1
# 1 car c'est des données continues (elles se suivent)
y1 = fichier_excel_f1['bac+5']
r1 = range(len(y1))

plt.bar(r1, y1, width = barWidth, color = ['deepskyblue' for i in y1],
           edgecolor = ['blue' for i in y1], linewidth = 1)


plt.xticks(range(len(fichier_excel_f1['taille entreprise'])), fichier_excel_f1['taille entreprise']) 

plt.show()

# Sur la page nuage, 1 case=1 réponse, on va dessiner un histogramme mais sans utiliser bar
liste_mots = np.array([],[])

for i in range(len(fichier_excel_f2['liste_mots'])):
    if (fichier_excel_f2['liste_mots'])